
const { User, Course, Payment, Enrollment } = require('../../../models')
const { Op } = require('sequelize')

exports.getDashboardStats = async () => {
  try {
    const [
      totalUsers,
      totalCoaches,
      totalStudents,
      totalCourses,
      publishedCourses,
      totalEnrollments,
      totalPayments,
    ] = await Promise.all([
      User.count(),
      User.count({ where: { role: 'coach' } }),
      User.count({ where: { role: 'student' } }),
      Course.count(),
      Course.count({ where: { status: 'published' } }),
      Enrollment.count(),
      Payment.count({ where: { status: { [Op.in]: ['completed', 'success'] } } }),
    ])

    const revenueSum = await Payment.sum('amount', {
      where: { status: { [Op.in]: ['completed', 'success'] } },
    })
    const totalRevenue = Number(revenueSum || 0)

    const recentUsers = await User.findAll({
      limit: 5,
      order: [['created_at', 'DESC']],
      attributes: ['id', 'name', 'email', 'role', 'status', 'created_at'],
    })

    const recentPayments = await Payment.findAll({
      limit: 5,
      order: [['created_at', 'DESC']],
      include: [
        { model: User, as: 'student', attributes: ['id', 'name', 'email'] },
        { model: Course, as: 'course', attributes: ['id', 'title'] },
      ],
    })

    return {
      status: true,
      message: 'Dashboard statistics fetched successfully.',
      data: {
        stats: {
          totalUsers,
          totalCoaches,
          totalStudents,
          totalCourses,
          publishedCourses,
          totalEnrollments,
          totalPayments,
          totalRevenue,
          coaches: totalCoaches,
          students: totalStudents,
          courses: totalCourses,
          enrollments: totalEnrollments,
          revenue: totalRevenue,
        },
        recentUsers,
        recentPayments,
      },
    }
  } catch (error) {
    console.error('❌ Error in AdminDashboardService.getDashboardStats:', error)
    return { status: false, message: error.message, data: null }
  }
}

exports.getReports = async () => {
  try {
    const revenueSum = await Payment.sum('amount', {
      where: { status: { [Op.in]: ['completed', 'success'] } },
    })
    const courses = await Course.findAll({
      include: [
        { model: User, as: 'coach', attributes: ['id', 'name', 'email'] },
        { model: Enrollment, as: 'enrollments', attributes: ['id'] },
        { model: Payment, as: 'payments', attributes: ['amount', 'status'] },
      ],
      order: [['created_at', 'DESC']],
    })

    const courseSales = courses.map((c) => {
      const sales = (c.enrollments || []).length
      const rev = (c.payments || [])
        .filter((p) => p.status === 'completed' || p.status === 'success')
        .reduce((sum, p) => sum + Number(p.amount || 0), 0)
      return {
        id: c.id,
        title: c.title,
        category: c.category || 'General',
        price: c.price || 0,
        status: c.status || 'draft',
        coach: c.coach ? { id: c.coach.id, name: c.coach.name, email: c.coach.email } : null,
        sales,
        revenue: rev,
      }
    })

    return {
      status: true,
      message: 'Reports data fetched successfully.',
      data: {
        reports: {
          revenue: Number(revenueSum || 0),
          courseSales,
        },
      },
    }
  } catch (error) {
    return { status: false, message: error.message, data: null }
  }
}
