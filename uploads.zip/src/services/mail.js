'use strict'

const nodemailer = require('nodemailer')
const { EmailConfig } = require('../models')

// Cache one transporter per smtp_host+username combo so we don't reconnect on every email.
const transporterCache = new Map()

const getTransporter = (config) => {
  const host = config.smtp_host || process.env.SMTP_HOST || 'smtp.gmail.com'
  const port = Number(config.smtp_port || process.env.SMTP_PORT || 465)
  const secure = config.smtp_secure !== undefined ? Boolean(Number(config.smtp_secure)) : true
  const user = config.smtp_username || process.env.SMTP_USER || 'kapilakshu848@gmail.com'
  const pass = (config.smtp_password && config.smtp_password !== 'testpassword123') ? config.smtp_password : (process.env.SMTP_PASS || 'zlgninioettnhazf')

  const key = `${host}:${port}:${user}:${pass}`
  if (!transporterCache.has(key)) {
    transporterCache.set(
      key,
      nodemailer.createTransport({
        host,
        port,
        secure,
        auth: { user, pass },
        connectionTimeout: 8000,
        greetingTimeout: 8000,
        socketTimeout: 8000,
      })
    )
  }
  return transporterCache.get(key)
}

// Replaces {{key}} placeholders in a template string with values from vars.
const interpolate = (template, vars = {}) =>
  String(template || '').replace(/{{\s*(\w+)\s*}}/g, (_, key) =>
    vars[key] !== undefined && vars[key] !== null ? String(vars[key]) : ''
  )

// The to/cc/bcc columns in email_configs may hold a single email, a comma/semicolon
// separated list, or a JSON array string — this normalizes all three into an array.
const parseRecipients = (raw) => {
  if (!raw) return []
  if (Array.isArray(raw)) return raw.filter(Boolean)
  const text = String(raw).trim()
  if (!text) return []
  if (text.startsWith('[')) {
    try {
      const parsed = JSON.parse(text)
      if (Array.isArray(parsed)) return parsed.filter(Boolean)
    } catch {
      // fall through to comma-split below
    }
  }
  return text.split(/[,;]/).map((item) => item.trim()).filter(Boolean)
}

const sendMail = async ({ module, action, coachId, to, cc, bcc, vars = {} }) => {
  const where = { module, action }
  if (coachId) where.coach_id = coachId
  const config = await EmailConfig.findOne({ where })
  if (!config) {
    console.log(`[mail:dev] no email_configs row for module="${module}" action="${action}"`)
    return { sent: false, reason: `No email_configs row for module="${module}" action="${action}"` }
  }

  if (config.status !== undefined && config.status !== null && Number(config.status) === 0) {
    console.log(`[mail:dev] email_configs row disabled for module="${module}" action="${action}"`)
    return { sent: false, reason: 'Email config is disabled (status = 0)' }
  }

  const toList = to ? parseRecipients(to) : parseRecipients(config.to)
  const ccList = [...parseRecipients(config.cc), ...parseRecipients(cc)]
  const bccList = [...parseRecipients(config.bcc), ...parseRecipients(bcc)]

  if (!toList.length) {
    console.log(`[mail:dev] no recipient for module="${module}" action="${action}" (pass "to" or set the config row's "to" column)`)
    return { sent: false, reason: 'Missing recipient email' }
  }

  const subject = interpolate(config.subject, vars)
  const html = interpolate(config.html_template, vars)
  const from = config.from_name ? `"${config.from_name}" <${config.from_email}>` : config.from_email

  if (!config.smtp_host || !config.smtp_username || !config.smtp_password) {
    console.log(`[mail:dev] to=${toList.join(',')} subject="${subject}" (SMTP fields missing in email_configs row)`)
    return { sent: false, reason: 'SMTP fields missing in email_configs row' }
  }

  try {
    const transporter = getTransporter(config)
    const info = await transporter.sendMail({
      from,
      to: toList,
      cc: ccList.length ? ccList : undefined,
      bcc: bccList.length ? bccList : undefined,
      subject,
      html,
    })
    console.log(`[mail:sent] to=${toList.join(',')} subject="${subject}" messageId=${info.messageId}`)
    return { sent: true, messageId: info.messageId }
  } catch (error) {
    console.log(`[mail:error] to=${toList.join(',')} subject="${subject}" ${error.message}`)
    return { sent: false, reason: error.message }
  }
}

module.exports = { sendMail }
